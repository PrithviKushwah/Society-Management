<footer class="footer py-4  ">
  
</footer>
<?php /**PATH D:\Society git\Society-Management\resources\views/components/footers/auth.blade.php ENDPATH**/ ?>