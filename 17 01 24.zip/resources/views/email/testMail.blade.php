<!DOCTYPE html>
<html>
<head>
    <title>AllPHPTricks.com</title>
</head>
<body>
    <h1>{{ $testMailData['title'] }}</h1>
    <p>{{ $testMailData['body'] }}</p>
</body>
</html>