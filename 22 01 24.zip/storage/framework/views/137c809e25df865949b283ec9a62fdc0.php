<span wire:click="destroy" class="d-sm-inline d-none">Sign
    Out</span>
<?php /**PATH D:\Society git\Society-Management\resources\views/livewire/auth/logout.blade.php ENDPATH**/ ?>