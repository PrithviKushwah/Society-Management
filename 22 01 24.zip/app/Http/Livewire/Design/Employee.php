<?php

namespace App\Http\Livewire\Design;

use Livewire\Component;

class Employee extends Component
{
    public function render()
    {
        return view('livewire.design.employee');
    }
}
